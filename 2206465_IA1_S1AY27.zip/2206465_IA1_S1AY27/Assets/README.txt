Put your images here: id-photo.jpg, any icons, etc.
